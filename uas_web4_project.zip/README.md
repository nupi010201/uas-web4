# UAS Web 4 - Laravel Filament Project

## Deskripsi
Proyek ini dibuat untuk memenuhi tugas Ujian Akhir Semester mata kuliah Pemrograman Web 4 dan Pemrograman Mobile.

## Teknologi yang Digunakan
- Laravel Framework
- Filament Admin
- MySQL Database

## Instalasi
1. Clone repository ini ke dalam komputer Anda.
2. Jalankan `composer install` untuk menginstal dependensi.
3. Konfigurasikan `.env` dengan pengaturan database.
4. Jalankan `php artisan migrate` untuk membuat tabel dalam database.
5. Jalankan `php artisan serve` untuk menjalankan server lokal.

## Profil Mahasiswa
- Nama: [Nama Mahasiswa]
- NIM: [NIM Mahasiswa]
